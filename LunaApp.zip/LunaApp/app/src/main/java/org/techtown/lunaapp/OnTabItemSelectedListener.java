package org.techtown.lunaapp;

public interface OnTabItemSelectedListener {
    public void onTabSelected(int position);
    public void showFragment2(Note item);
}
